package com.app.dto;

public enum Role {
	ADMIN, VENDOR, USER
}
