package com.app.entities;

public enum OrderStatus {

	SCHEDULED,PROCESSING,COMPLETED
	
}
