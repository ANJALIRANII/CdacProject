package com.app.dto;

public class vehicle {

}
